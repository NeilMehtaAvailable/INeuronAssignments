##Write a Python Program to Transpose a Matrix?
import numpy


def CatchValueErrorINT(msg):
    faultfreeinttag = ''
    while True:
        if type(faultfreeinttag) == int:
            break
        else:
            try:
                faultfreeinttag = int(input(msg))
            except:
                print("Enter INT values only")
    return faultfreeinttag


try:
    numofrows = int(input("Enter the INT number of rows in each matrix: "))
except ValueError:
    msg = 'Enter INT values only for the number of rows: '
    numofrows = CatchValueErrorINT(msg)
try:
    numofcolumns = int(input("Enter the INT number of columns in each matrix: "))
except ValueError:
    msg = 'Enter INT values only for the number of columns: '
    numofcolumns = CatchValueErrorINT(msg)


WholeMatrix = numpy.zeros((numofrows, numofcolumns))
for i in range(1,numofrows + 1):
    for j in range(1,numofcolumns + 1):
        print("Enter an element of Matrix at location (", i, ",", j, ") of any datatype:")
        WholeMatrix[i - 1][j - 1] = str(input())


ResultMatrix = numpy.zeros((numofcolumns, numofrows))
for k in range(0, numofcolumns):
    for l in range(0, numofrows):
        ResultMatrix[k,l] = WholeMatrix[l,k]


print("The resultant transposed matrix is:", ResultMatrix)