##Write a Python Program to Add Two Matrices?
import numpy


def CatchValueErrorINT(msg):
    faultfreeinttag = ''
    while True:
        if type(faultfreeinttag) == int:
            break
        else:
            try:
                faultfreeinttag = int(input(msg))
            except:
                print("Enter INT values only")
    return faultfreeinttag


def CatchValueErrorFLOAT(msg):
    faultfreefloattag = ''
    while True:
        if type(faultfreefloattag) == float:
            break
        else:
            try:
                faultfreefloattag = float(input(msg))
            except:
                print("Enter INT or FLOAT values only")
    return faultfreefloattag


try:
    numofmatrix = int(input("Enter the INT number of matrices you want to add: "))
except ValueError:
    msg = 'Enter INT values only for the number of matrices: '
    numofmatrix = CatchValueErrorINT(msg)
try:
    numofrows = int(input("Enter the INT number of rows in each matrix: "))
except ValueError:
    msg = 'Enter INT values only for the number of rows: '
    numofrows = CatchValueErrorINT(msg)
try:
    numofcolumns = int(input("Enter the INT number of columns in each matrix: "))
except ValueError:
    msg = 'Enter INT values only for the number of columns: '
    numofcolumns = CatchValueErrorINT(msg)


WholeMatrix = numpy.zeros((numofmatrix, numofrows, numofcolumns), dtype = 'float')
for i in range(1, numofmatrix + 1):
    print("For matrix", i, ":")
    for j in range(1,numofrows + 1):
        for k in range(1,numofcolumns + 1):
            try:
                print("    Enter an element of Matrix", i,"at location (", j, ",", k, ") of FLOAT or INT type:")
                element = float(input())
                WholeMatrix[i - 1][j - 1][k - 1] = element
            except ValueError:
                msg = 'Enter INT or FLOAT values only for the element: '
                WholeMatrix[i - 1][j - 1][k - 1] = CatchValueErrorFLOAT(msg)


ResultMatrix = numpy.zeros((numofrows, numofcolumns), dtype = 'float')
for l in range(1, numofmatrix + 1):
    ResultMatrix = ResultMatrix + WholeMatrix[l - 1][:][:]


print("The resultant addition matrix is:", ResultMatrix.astype(float))