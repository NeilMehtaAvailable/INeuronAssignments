##Write a Python Program to Sort Words in Alphabetic Order?
stringseries = input("Enter a sentence you want to sort according to its word's first alphabet: ")
listseries = stringseries.split()
dictseries = {}
for i in listseries:
    dictseries[i.lower()] = i
sortstring = ' '.join(dictseries[j] for j in sorted(dictseries))
print(sortstring)
