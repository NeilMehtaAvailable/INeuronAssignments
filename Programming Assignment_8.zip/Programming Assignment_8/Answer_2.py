##Write a Python Program to Multiply Two Matrices?
import numpy


def CatchValueErrorINT(msg):
    faultfreeinttag = ''
    while True:
        if type(faultfreeinttag) == int:
            break
        else:
            try:
                faultfreeinttag = int(input(msg))
            except:
                print("Enter INT values only")
    return faultfreeinttag


def CatchValueErrorFLOAT(msg):
    faultfreefloattag = ''
    while True:
        if type(faultfreefloattag) == float:
            break
        else:
            try:
                faultfreefloattag = float(input(msg))
            except:
                print("Enter INT or FLOAT values only")
    return faultfreefloattag


try:
    numofmatrix = int(input("Enter the INT number of matrices you want to multiply: "))
except ValueError:
    msg = 'Enter INT values only for the number of matrices: '
    numofmatrix = CatchValueErrorINT(msg)


numofrowsinmatrices = []
numofcolumnsinmatrices = []


for i in range(1, numofmatrix + 1):
    try:
        print("Enter the INT number of rows for matrix", i, ": ")
        numofrowsinmatrices.append(int(input("")))
    except ValueError:
        msg = 'Enter INT values only for the number of rows: '
        numofrowsinmatrices.append(CatchValueErrorINT(msg))
    try:
        print("Enter the INT number of columns for matrix", i, ": ")
        numofcolumnsinmatrices.append(int(input("")))
    except ValueError:
        msg = 'Enter INT values only for the number of columns: '
        numofcolumnsinmatrices.append(CatchValueErrorINT(msg))


carryvalue2 = numofrowsinmatrices[1]


for m in range(1, numofmatrix - 1):
    if numofcolumnsinmatrices[m - 1] == carryvalue2:
        carryvalue2 = numofrowsinmatrices[m + 1]
    else:
        print("The matrices dimensions cannot be multiplied")
        exit()


WholeMatrix = numpy.zeros((numofmatrix, int(max(numofrowsinmatrices)), int(max(numofcolumnsinmatrices))), dtype = 'float')
for j in range(1, numofmatrix + 1):
    print("For matrix", j, ":")
    for k in range(1, numofrowsinmatrices[j - 1] + 1):
        for l in range(1, numofcolumnsinmatrices[j - 1] + 1):
            try:
                print("    Enter an element of Matrix", j,"at location (", k, ",", l, ") of FLOAT or INT type:")
                WholeMatrix[j - 1][k - 1][l - 1] = float(input())
            except ValueError:
                msg = 'Enter INT or FLOAT values only for the element: '
                WholeMatrix[j - 1][k - 1][l - 1] = CatchValueErrorFLOAT(msg)


MultiplierMatrix = WholeMatrix[0, 0 : numofrowsinmatrices[0], 0 : numofcolumnsinmatrices[0]]
for n in range(1, numofmatrix):
    ResultMatrix = MultiplierMatrix.dot(WholeMatrix[n, 0:numofrowsinmatrices[n], 0:numofcolumnsinmatrices[n]])
    MultiplierMatrix = ResultMatrix


print("The resultant addition matrix is:", ResultMatrix.astype(float))