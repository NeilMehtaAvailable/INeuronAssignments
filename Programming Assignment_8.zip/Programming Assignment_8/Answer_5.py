##Write a Python Program to Remove Punctuation From a String?
stringseries = input("Enter a sentence where you want to eliminate punctuation symbols: ")
eliminatesymbols = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
for character in stringseries:
    if character in eliminatesymbols:
        stringseries = stringseries.replace(character, "")

print(stringseries)




