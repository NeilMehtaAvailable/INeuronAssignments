##Write a Python program to do arithmetical operations addition and division.?
a = int(input("Enter value 1 or numerator for addition or divison respectively: "))
b = int(input("Enter value 2 or non-zero denominator for addition or divison respectively: "))
print("The result of addition is: ", a + b)
print("The result of divison is: ", a / b)