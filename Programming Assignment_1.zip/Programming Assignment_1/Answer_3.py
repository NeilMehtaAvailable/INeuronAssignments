##Write a Python program to find the area of a triangle?
b = int(input("Enter the base length of the triangle: "))
h = int(input("Enter the height length of the triangle: "))
print("The area of the triangle is: " , 1 / 2 * b * h, " units")
