##Write a Python program to print "Hello Python"?
print("Hello Python")