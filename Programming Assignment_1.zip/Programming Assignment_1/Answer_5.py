##Write a Python program to generate a random number?
import random
print("A random integer is: ", random.randint(0,100000000))