##Write a Python program to swap two variables?
var1 = int(input("Enter variable1: "))
var2 = int(input("Enter variable2: "))
var3 = var2
var2 = var1
var1 = var3
print("The value of variable1: ", var1)
print("The value of variable2: ", var2)