##Write a Python Program to Convert Decimal to Binary, Octal and Hexadecimal?
num = int(input("Enter decimal number you want to convert to BINARY, OCTAL & HEXADECIMAL: "))

num_for_binary = num
num_for_octal = num
num_for_hexa = num
#Convert DECIMAL to BINARY
binaryfactor = 2
binary_bits = []
octalfactor = 8
octal_bits = []
hexafactor = 16
hexa_bits = []

while True:
    if num_for_binary == 1:
        binary_bits.append(1)
        break
    elif num_for_binary % binaryfactor == 0:
        num_for_binary = int(num_for_binary / binaryfactor)
        binary_bits.append(0)
    else:
        num_for_binary = int((num_for_binary - 1) / binaryfactor)
        binary_bits.append(1)
binary_bits.reverse()

while True:
    if num_for_octal <= octalfactor:
        octal_bits.append(num_for_octal)
        octal_bits.reverse()
        break
    reminder_octal = num_for_octal % octalfactor
    octal_bits.append(reminder_octal)
    num_for_octal = int(num_for_octal / octalfactor)

while True:
    reminder_hexa = num_for_hexa % hexafactor
    if reminder_hexa == 10:
        hexa_bits.append("A")
    elif reminder_hexa == 11:
        hexa_bits.append("B")
    elif reminder_hexa == 12:
        hexa_bits.append("C")
    elif reminder_hexa == 13:
        hexa_bits.append("D")
    elif reminder_hexa == 14:
        hexa_bits.append("E")
    elif reminder_hexa == 15:
        hexa_bits.append("F")
    else:
        hexa_bits.append(reminder_hexa)
    num_for_hexa = int(num_for_hexa / hexafactor)
    if num_for_hexa <= hexafactor:
        if num_for_hexa == 10:
            num_for_hexa = "A"
        elif num_for_hexa == 11:
            num_for_hexa = "B"
        elif num_for_hexa == 12:
            num_for_hexa = "C"
        elif num_for_hexa == 13:
            num_for_hexa = "D"
        elif num_for_hexa == 14:
            num_for_hexa = "E"
        elif num_for_hexa == 15:
            num_for_hexa = "F"
        elif num_for_hexa == 16:
            num_for_hexa = 0
        hexa_bits.append(num_for_hexa)
        hexa_bits.reverse()
        break

print("The binary of", num, "is", list(binary_bits))
print("The octal of", num, "is", octal_bits)
print("The hexadecimal of", num, "is", hexa_bits)