##WWrite a Python Program to Find HCF?

num1 = int(input("Enter num1 whose HCF you want to calculate: "))
num2 = int(input("Enter num2 whose HCF you want to calculate: "))

savednewnums1 = []
savednewnums2 = []
multipliernums1 = []
multipliernums2 = []
temp1 = 1
temp2 = 1
hcf = 1

if num1 >= num2:
    z = num1
else:
    z = num2

for i in range(2, z+1):
    if num1 % i == 0:
        while True:
            newnums1 = int(num1 / i)
            num1 = newnums1
            savednewnums1.append(i)
            if (num1 < i) or (num1 % i != 0):
                break
    if num2 % i == 0:
        while True:
            newnums2 = int(num2 / i)
            num2 = newnums2
            savednewnums2.append(i)
            if (num2 < i) or (num2 % i != 0):
                break

if int(len(savednewnums1)) <= int(len(savednewnums2)):
    for j in savednewnums1:
        if j in savednewnums2:
            multipliernums1.append(j)
            savednewnums2.remove(j)
    for k in multipliernums1:
        hcf = hcf * k
    print("HCF is: ", hcf)
else:
    for k in savednewnums2:
        if j in savednewnums1:
            multipliernums2.append(j)
            savednewnums1.remove(j)
    for k in multipliernums2:
        hcf = temp2 * k
    print("HCF is: ", hcf)
