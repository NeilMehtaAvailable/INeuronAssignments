##Write a Python Program to Make a Simple Calculator with 4 basic mathematical operations?
def wronginput(userinput13):
    if userinput13 != "ce":
        while True:
            userinput13 = input("Enter a int or float value only: ")
            try:
                userinput13float = float(userinput13)
                break
            except ValueError:
                if (type(userinput13) != "int") or (type(userinput13) != "float"):
                    l = 0
                    print("Enter INT or FLOAT values only")
        return userinput13float, l

    else:
        userinput13float = 0.0
        l = 1
        return userinput13float, l



userinput1 = input("Enter an integer or float number for basic calculation. Press 'ce' to reset: ")
try:
    userinputfloat1 = float(userinput1)
    m = 0
except ValueError:
     userinputfloat1 , m = wronginput(userinput1)

if m == 0:
    while True:
        userinput2 = input("Enter a arithmatic operator for basic calculation. Press 'ce' to reset: ")
        if userinput2 == "ce":
            break

        elif userinput2 == "+":
            userinput2value = 1

        elif userinput2 == "-":
            userinput2value = 2

        elif userinput2 == "*":
            userinput2value = 3

        elif userinput2 == "/":
            userinput2value = 4

        else:
            while True:
                userinput2 = input("Enter basic arithmatic operator only +, -, * or /: ")
                if (userinput2 == "+" or userinput2 == "-" or userinput2 == "*" or userinput2 == "/" ):
                    break


        userinput3 = input("Enter an integer or float number for basic calculation. Press 'ce' to reset: ")
        if userinput2 == "ce":
            break
        try:
            userinputfloat3 = float(userinput3)
        except ValueError:
            userinputfloat3 = wronginput(userinput3)


        if userinput2value == 1:
            a = userinputfloat1 + userinputfloat3
            print("The value of ", userinputfloat1, "+",  userinputfloat3, "=", a, " Press 'ce' to reset")
            userinputfloat1 = a
        elif userinput2value == 2:
            a = userinputfloat1 - userinputfloat3
            print("The value of ", userinputfloat1, "-",  userinputfloat3, "=", a, " Press 'ce' to reset")
            userinputfloat1 = a
        elif userinput2value == 3:
            a = userinputfloat1 * userinputfloat3
            print("The value of ", userinputfloat1, "*",  userinputfloat3, "=", a, " Press 'ce' to reset")
            userinputfloat1 = a
        elif userinput2value == 4:
            try:
                x = float(userinputfloat1 / userinputfloat3)
                print("The value of ", userinputfloat1, "/",  userinputfloat3, "=", x)
                userinputfloat1 = x
            except ZeroDivisionError:
                while True:
                    userinputx = input("Enter a non-zero int or float  denominator. Press 'ce' to reset: ")
                    userinputfloatx = float(userinputx)
                    if userinputfloatx != 0.0:
                        try:
                            x = userinputfloat1 / userinputfloatx
                            print("The value of ", userinputfloat1, "/", userinputfloatx, "=", x, " Press 'ce' to reset")
                            userinputfloat1 = x
                            break
                        except ValueError:
                            userinputfloatx = wronginput(userinputx)










