##Write a Python Program To Find ASCII value of a character?
regular = input("Enter tbe character  (not numbers) whose ASCII value you want: ")
asciichar = ord(regular)
print("The ASCII value is: ", asciichar)