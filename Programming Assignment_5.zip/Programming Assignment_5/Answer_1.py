num1 = int(input("Enter num1 whose LCM you want to calculate: "))
num2 = int(input("Enter num2 whose LCM you want to calculate: "))

if num1 >= num2:
    z = num1
else:
    z = num2
    while True:
        if ((z % num1 == 0) and (z % num2 == 0)):
            break
        z += 1

print("LCM is: ", z)