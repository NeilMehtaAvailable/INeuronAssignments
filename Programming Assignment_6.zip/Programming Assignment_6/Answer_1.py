##Write a Python Program to Display Fibonacci Sequence Using Recursion?
def fibrec(numtermsint):
    if numtermsint == 1:
        return 0
    elif numtermsint == 2:
        return 1
    else:
        return fibrec(numtermsint - 1) + fibrec(numtermsint - 2)

while True:
    try:
        numterms = input("Enter the number of terms till which you want to see Fibonacci series: ")
        numtermsint = int(numterms)
        if numtermsint >= 1:
            break
        else:
            print("Enter a positive integer only")
    except ValueError:
         print("Enter INT values only")


for i in range(1, numtermsint + 1):
    print(fibrec(i))
