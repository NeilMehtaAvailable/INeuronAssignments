##Write a Python Program to calculate the natural logarithm of any number?
import cmath
def ValueErrorcatch(msg):
    while True:
        try:
            l = input(msg)
            lfloat = float(l)
            break
        except ValueError:
             print("Enter FLOAT or INT values only")
    return lfloat


while True:
    try:
        realfloat = ValueErrorcatch("Enter the real part of the number of whose natural log you want to calculate: ")
        imaginaryfloat = ValueErrorcatch("Enter the imaginary part of the number of whose natural log you want to calculate: ")
        x = cmath.log(realfloat, imaginaryfloat)
        print("The Natural log of real", realfloat, "and imaginary", imaginaryfloat, "is: ", x)
        break
    except ValueError:
        print("Real and Imaginary parts cannot be zero at the same time. Put in non-zero values for atleast one part.")