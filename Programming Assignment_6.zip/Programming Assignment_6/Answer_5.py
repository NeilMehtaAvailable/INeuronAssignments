##Write a Python Program for cube sum of first n natural numbers?
import math
def ValueErrorcatch(l):
    while True:
        try:
            lint = int(l)
            if lint > 0:
                break
            else:
                print("Enter a Natural number only")
        except ValueError:
             print("Enter INT values only")
    return lint

firstcubes = input("Enter first how many Natural number cubes you want to find: ")
intfirstcubes = ValueErrorcatch(firstcubes)
l = 0
for i in range(1, intfirstcubes + 1):
    l = int(math.pow(i, 3)) + l

print("The sum of first ", intfirstcubes, " natural numbers cubes is: ", l)
