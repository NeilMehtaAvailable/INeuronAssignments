##Write a Python Program to Find Factorial of Number Using Recursion?
def fact(n):
    if n == 0:
        return 1
    elif n == 1:
        return 1
    elif n == 2:
        return 2
    else:
        for i in range(2, n + 2):
            k = (i -1) * fact(i - 2)
        return k

while True:
    try:
        l = input("Enter the INT whose factorial you want to find: ")
        lint = int(l)
        if lint >= 0:
            break
        else:
            print("Enter a Whole number only")
    except ValueError:
         print("Enter INT values only")

print("The factorial of", lint, "is: ", fact(lint))



