##Write a Python Program to calculate your Body Mass Index?
def ValueErrorcatch(msg):
    while True:
        try:
            l = input(msg)
            lint = int(l)
            if lint > 0:
                break
            else:
                print("Enter a Natural number only")
        except ValueError:
             print("Enter INT values only")
    return lint

weightint = ValueErrorcatch("Enter the weight of the subject in kg only: ")

heightint = ValueErrorcatch("Enter the height of the subject in m2 only: ")

print("The BMI of the subject is: ", weightint / heightint, "kg/m2")
