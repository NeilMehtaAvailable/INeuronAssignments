##Write a Python Program for array rotation?
def ValueErrorcatch(msg):
    while True:
        try:
            l = input(msg)
            lint = int(l)
            if lint > 0:
                break
            else:
                print("Enter a Natural number only")
        except ValueError:
             print("Enter INT values only")
    return lint

arrayinput1 = input("Enter array elements seperated by commas: ")
arrayinput1 = arrayinput1.split(',')
arrayinput2 = ValueErrorcatch("Enter the value by which you want to rotate the array: ")
arraytemp1 = list(arrayinput1[0 : arrayinput2])
del arrayinput1[0 : arrayinput2]
arrayoutput = arrayinput1 + arraytemp1
print("The rotated array is: ", arrayoutput)



