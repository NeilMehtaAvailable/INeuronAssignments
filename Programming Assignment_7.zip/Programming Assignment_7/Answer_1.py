##Write a Python Program to find sum of array?
arrayinput = input("Enter Int or float elements seperated by commas: ")
arrayinput = arrayinput.split(',')
arrayinputnums = []
i = 0
for i in range(0, len(arrayinput)):
    try:
        arrayinputnums.append(float(arrayinput[i]))
    except ValueError:
        pass
print("The sum of INT and FLOAT elements in the array is: ", sum(arrayinputnums))





