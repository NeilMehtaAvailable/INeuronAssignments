##Write a Python Program to check if given array is Monotonic?
def ValueErrorcatch(l):
    while True:
        try:
            lfloat = float(l)
            k = 0
            break
        except ValueError:
            m = input("Numerical values only. Eliminate ", l, "and enter a new element: ")
            k = 1
    return lfloat, k
inputarray = input("Enter the INT OR FLOAT elements (seperated by commas) for which you want to check monotone or not: ")
inputarray = list(inputarray.split(','))

checkedinputarray = []
for i in inputarray:
    checkedvalue, iserror = ValueErrorcatch(i)

    while iserror == 1:
        inputarray2 = input("Numerical values only. Eliminate ", i, "and enter a new element: ")
        checkedvalue, iserror = ValueErrorcatch(i)

    checkedinputarray.append(checkedvalue)

j = 0
mono = []
for  j in range(0, int(len(checkedinputarray)) - 1):
    if checkedinputarray[j] < checkedinputarray[j+1]:
        mono.append("True")
    elif checkedinputarray[j] > checkedinputarray[j + 1]:
        mono.append("False")
    elif checkedinputarray[j] == checkedinputarray[j + 1]:
        mono.append("True")

if mono == "True":
    print("The given array is Monotonic")
elif mono == "False":
    print("The given array is Monotonic")
else:
    print("The given array is not Monotonic")








