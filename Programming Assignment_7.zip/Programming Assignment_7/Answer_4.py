##Write a Python Program to Split the array and add the first part to the end?

#The question is not clear- Concatenate str + str or str + int or int + int