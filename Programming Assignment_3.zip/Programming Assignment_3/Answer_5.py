##Write a Python Program to Print all Prime Numbers in an Interval of 1-10000?
#pip install sympy before running this program
from sympy import isprime
upperlimit = 100000
count = 0
for i in range(1, upperlimit + 1):
    if isprime(i) is True:
        print(i," is a prime number")
        count = count + 1
    else:
        pass
print("Between 1 and", upperlimit, "there are", count, "prime numbers")