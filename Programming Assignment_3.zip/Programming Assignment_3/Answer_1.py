##Write a Python Program to Check if a Number is Positive, Negative or Zero?
provided = float(input("Enter a real number: "))
if provided == 0:
    print("The given number is zero")
elif provided > 0:
    print("The given number is positive")
else:
    print("The given number is negative")
