##Write a Python Program to Check Leap Year?
leapyearcheck = int(input("Enter the year number: "))
if leapyearcheck % 4 == 0:
    print("This is a leap year")
else:
    print("This is not a leap year")
