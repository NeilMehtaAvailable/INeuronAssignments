##Write a Python Program to Check if a Number is Odd or Even?
eveodd = int(input("Enter an integer: "))
if eveodd % 2 == 0:
    print("The given number is even")
else:
    print("The given number is odd")