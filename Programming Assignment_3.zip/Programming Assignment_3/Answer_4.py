##Write a Python Program to Check Prime Number?
#pip install sympy before running this program
from sympy import isprime
isitprime = int(input("Enter a real integer to check its prime or not: "))
if isprime(isitprime) is True:
    print("That is a prime number")
else:
    print("That is not a prime number")