##Write a Python program to convert Celsius to Fahrenheit?
cel = int(input("Enter the Celsius: "))
print("The equivalent Farenheit: ", (cel*9/5) + 32)