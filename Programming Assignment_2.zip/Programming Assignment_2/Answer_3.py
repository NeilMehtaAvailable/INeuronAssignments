##Write a Python program to display calendar?
import calendar
y = int(input("Enter the year whose months and dates you want to see: "))
for i in range(1,13):
    print(calendar.month(y,i))