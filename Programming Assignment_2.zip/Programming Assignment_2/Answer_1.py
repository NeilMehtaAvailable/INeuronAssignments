##Write a Python program to convert kilometers to miles?
kms = int(input("Enter the number of kilometers to be converted to miles: "))
print(kms, "kms are ", kms * 0.621371, "miles")