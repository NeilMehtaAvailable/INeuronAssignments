##Write a Python program to solve quadratic equation?
import cmath
from math import sqrt
print("In the quadratic equation ax^2 + bx + c = 0, soslving for x:")
a = int(input("Enter the value for 'a' : "))
b = int(input("Enter the value for 'b' : "))
c = int(input("Enter the value for 'c' : "))
x1 = (-b + cmath.sqrt((b**2) - 4 * a * c)) / (2 * a)
x2 = (-b - cmath.sqrt((b**2) - 4 * a * c)) / (2 * a)
print("The solutions for x are : ", x1, " and ", x2)