##Write a Python program to swap two variables without temp variable?
l = input("Enter variable 1: ")
m = input("Enter variable 2: ")
l,m = m,l
print("After swapping variables without using 3rd varible, variable 1:", l, " and variable 2: ",m)
