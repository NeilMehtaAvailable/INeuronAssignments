##Write a Python Program to Find the Factorial of a Number?
infactnum = int(input("Enter a positive integer: "))
outfactnum = 1
for i in range(infactnum, 0, -1):
    outfactnum = i * outfactnum
print("The factorial of", infactnum, "is", outfactnum)