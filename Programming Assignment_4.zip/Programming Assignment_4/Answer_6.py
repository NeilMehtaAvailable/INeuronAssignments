##Write a Python Program to Find the Sum of Natural Numbers?
lastnum = int(input("Enter the number till which you want to find the sum of Natural no.s: "))
sum = 0
for p in range(lastnum + 1):
    sum = sum + p
print("The sum is: ",sum)