##Write a Python Program to Find Armstrong Number in an Interval?
armnum_lowerlimit = int(input("Enter the positive integer (>10) lower limit for search of Armstrong number: "))
armnum_upperlimit = int(input("Enter the positive integer (>10) upper limit for search of Armstrong number: "))
temp_value_holder2 = armnum_lowerlimit
print("The Armstrong numbers in the range are:")
for temp_value_holder in range(armnum_lowerlimit, armnum_upperlimit + 1, 1):
    temp_value_holder2 = temp_value_holder
    summing = 0
    power = 0
    reminderlist = []
    while temp_value_holder2 > 0:
        power = power + 1
        finallevelremainder = int(temp_value_holder2 % 10)
        temp_value_holder2 = int(temp_value_holder2 / 10)
        reminderlist.append(finallevelremainder)
    for i in range(0, power):
        summing = summing + reminderlist[i] ** power
    if summing == temp_value_holder:
        print(temp_value_holder)
    else:
        pass

