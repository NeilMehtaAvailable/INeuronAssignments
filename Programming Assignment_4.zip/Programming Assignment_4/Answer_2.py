##Write a Python Program to Display the multiplication Table?
tableof = int(input("Multiplication table of? "))
tabletill = int(input("Multiplicaton table till? "))
for i in range(1, tabletill + 1):
    print(tableof, "*", i, "=", tableof * i)
