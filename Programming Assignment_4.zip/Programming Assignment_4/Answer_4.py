##Write a Python Program to Check Armstrong Number?
armnum = int(input("Enter a number to check whether its Armstrong number or not: "))
tempholder = armnum
accumulator = 0
while tempholder > 0:
     lastlevelremainder = tempholder % 10
     accumulator = accumulator + lastlevelremainder**3
     tempholder = int(tempholder / 10)

if accumulator == armnum:
    print(armnum,"is an Armstrong number")
else:
    print(armnum, "is not an Armstrong number")
