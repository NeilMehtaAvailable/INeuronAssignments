##Write a Python Program to Print the Fibonacci sequence?
fibupperlimit = int(input("Enter upper limit of Fibonacci sequence: "))
v = 0
v1 = 1
newnum = 1
print("The Fibonacci sequence is: ")
while newnum <= fibupperlimit:
    print(newnum, ",")
    newnum = v + v1
    v = v1
    v1 = newnum


